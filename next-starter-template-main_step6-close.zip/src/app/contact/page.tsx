export default function ContactPage() {
  return (
    <main style={{ padding: '40px 16px', textAlign: 'center' }}>
      <h1>Contact Us</h1>
      <p>
        For general inquiries or volunteer opportunities, email
        LouGehrigFanClub@gmail.com.
      </p>
    </main>
  );
}
