# LGFC-Lite Baseline Procedure (v1)

This repo has had repeated ZIP/PR recovery cycles. Before any further feature work, establish a clean baseline.

## Baseline definition
Baseline is achieved when all of the following are true:

1) **B2 S3 smoke test is GREEN** in CI
- Workflow(s) run `bash scripts/b2_s3_smoketest.sh` successfully.

2) **Inventory generation is repeatable**
- `bash scripts/b2_inventory_report.sh` produces:
  - `data/b2/inventory_latest.json`
  - `data/b2/inventory_latest.csv`

3) **Enriched inventory exists (day-1 metadata)**
- `bash scripts/b2_enrich_inventory.sh` produces:
  - `data/b2/inventory_enriched_latest.json`
  - `data/b2/inventory_enriched_latest.csv`

4) **Public site surfaces real Lou Gehrig content**
- Homepage hero copy is Gehrig-specific.
- `/about` has complete, non-placeholder copy.

## Tagging the baseline (manual)
Once the above is true on `main`:

```bash
git tag -a lgfc-lite-v1.0-baseline -m "LGFC-Lite baseline: B2 connectivity + inventory + content"
git push origin lgfc-lite-v1.0-baseline
```

From that point forward: **additive PRs only** (no restructures, no ZIP overwrites).
