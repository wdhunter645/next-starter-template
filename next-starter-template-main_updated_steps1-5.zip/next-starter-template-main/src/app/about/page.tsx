import React from "react";
import { fetchPageContent } from "@/lib/pageContent";

export default async function Page() {
  const data = await fetchPageContent("/about");
  const sections = data?.sections;

  const title = sections?.title?.content ?? "About the Lou Gehrig Fan Club";
  const leadHtml = sections?.lead_html?.content ?? null;
  const bodyHtml = sections?.body_html?.content ?? null;

  return (
    <main style={{ ...styles.main }}>
      <h1 style={{ ...styles.h1 }}>{title}</h1>

      {leadHtml ? (
        <p style={{ ...styles.lead }} dangerouslySetInnerHTML={{ __html: leadHtml }} />
      ) : (
        <p style={{ ...styles.lead }}>
          Henry Louis &ldquo;Lou&rdquo; Gehrig (1903–1941) remains one of baseball’s most respected figures—an
          all-time great who paired historic production with uncommon humility. His life and his famous farewell
          made him an enduring symbol of strength, gratitude, and the ongoing fight against ALS.
        </p>
      )}

      {bodyHtml ? (
        <div style={{ ...styles.body }} dangerouslySetInnerHTML={{ __html: bodyHtml }} />
      ) : (
        <>
          <h2 style={{ ...styles.h2 }}>Who Lou Gehrig was</h2>
          <p style={{ ...styles.p }}>
            Gehrig was a first baseman for the New York Yankees whose consistency and power helped define an era.
            He played from 1923 to 1939 and became known as the &ldquo;Iron Horse&rdquo; for his reliability and
            toughness, appearing in 2,130 consecutive games—a record that stood for decades.
          </p>
          <p style={{ ...styles.p }}>
            On the field, he was a complete hitter: patience, contact, and power. His career numbers place him
            among the game’s elite, and his October performances helped anchor multiple championship runs.
          </p>

          <h2 style={{ ...styles.h2 }}>ALS and &ldquo;The Luckiest Man&rdquo; speech</h2>
          <p style={{ ...styles.p }}>
            In 1939, Gehrig was diagnosed with amyotrophic lateral sclerosis (ALS), the disease that would later
            be widely associated with his name. On July 4, 1939, at Yankee Stadium, he delivered a farewell
            address that remains one of the most moving moments in sports history—choosing gratitude and grace
            over bitterness.
          </p>

          <h2 style={{ ...styles.h2 }}>What this fan club is for</h2>
          <p style={{ ...styles.p }}>
            The Lou Gehrig Fan Club exists to celebrate Gehrig’s life, protect the historical record, and build a
            place where fans can share photos, stories, and memorabilia—while also supporting awareness and
            fundraising tied to ALS-related causes.
          </p>

          <h2 style={{ ...styles.h2 }}>What you’ll find here</h2>
          <ul style={{ ...styles.ul }}>
            <li style={{ ...styles.li }}>
              A growing photo and memorabilia archive, including rare and privately-sourced items.
            </li>
            <li style={{ ...styles.li }}>
              Club posts, discussions, and member submissions that expand the story beyond a single source.
            </li>
            <li style={{ ...styles.li }}>
              Events and milestones—plus ongoing efforts to connect fandom with meaningful impact.
            </li>
          </ul>

          <p style={{ ...styles.p }}>
            If you have Gehrig-related items, family history, newspaper clippings, or collection notes you’re willing
            to share, this site is built to preserve them responsibly and give credit where it’s due.
          </p>
        </>
      )}
    </main>
  );
}

const styles: Record<string, React.CSSProperties> = {
  main: { padding: "40px 16px", maxWidth: 900, margin: "0 auto" },
  h1: { fontSize: 34, lineHeight: 1.15, margin: "0 0 12px 0" },
  h2: { fontSize: 22, lineHeight: 1.25, margin: "22px 0 10px 0" },
  lead: { fontSize: 18, lineHeight: 1.6, margin: "0 0 18px 0" },
  body: { fontSize: 16, lineHeight: 1.7 },
  p: { fontSize: 16, lineHeight: 1.7, margin: "0 0 14px 0" },
  ul: { paddingLeft: 18, margin: "0 0 14px 0" },
  li: { margin: "0 0 8px 0", lineHeight: 1.6 },
};
