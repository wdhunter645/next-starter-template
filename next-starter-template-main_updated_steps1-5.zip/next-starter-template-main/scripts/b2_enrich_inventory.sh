#!/usr/bin/env bash
set -euo pipefail

# Enriches an inventory JSON/CSV with lightweight derived metadata (day-1 ready).
#
# Input:
#   data/b2/inventory_latest.json (or pass --in <file>)
# Output:
#   data/b2/inventory_enriched_latest.json
#   data/b2/inventory_enriched_latest.csv
#
# Rules:
# - No AI calls, no external services.
# - Only deterministic heuristics based on the object key/path.

in_path="data/b2/inventory_latest.json"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --in) in_path="$2"; shift 2;;
    *) echo "Unknown arg: $1"; exit 2;;
  esac
done

if [[ ! -f "$in_path" ]]; then
  echo "ERROR: Missing input inventory JSON: $in_path"
  echo "Run: bash scripts/b2_inventory_report.sh"
  exit 2
fi

out_json="data/b2/inventory_enriched_latest.json"
out_csv="data/b2/inventory_enriched_latest.csv"

node - <<'NODE' "$in_path" "$out_json" "$out_csv"
import fs from "node:fs";

const [,, inPath, outJson, outCsv] = process.argv;
const raw = JSON.parse(fs.readFileSync(inPath, "utf8"));
const keys = raw?.keys ?? [];

function classify(key) {
  const k = key.toLowerCase();

  // type (very coarse)
  let type = "photo";
  if (/(card|program|ticket|autograph|signature|newspaper|clipping|letter|bat|jersey|uniform|scorecard|patch|pin|button|plaque|trophy|magazine)/.test(k)) {
    type = "memorabilia";
  }

  // era (we keep it simple; anything Gehrig-related is pre-1939 by default)
  const era = "pre-1939";

  // source (unknown unless path hints)
  let source = "unknown";
  if (/(mlb|topps|getty|ap|upi|libraryofcongress|loc|museum)/.test(k)) source = "public";
  if (/(private|collection|estate|family)/.test(k)) source = "private";

  // is_memorabilia
  const is_memorabilia = type === "memorabilia";

  // tags (minimal)
  const tags = [];
  if (k.includes("yankee") || k.includes("yankees") || k.includes("nyy")) tags.push("yankees");
  if (k.includes("worldseries") || k.includes("world-series")) tags.push("world-series");
  if (k.includes("allstar") || k.includes("all-star")) tags.push("all-star");
  if (k.includes("portrait")) tags.push("portrait");
  if (k.includes("action")) tags.push("action");

  // title (best-effort from filename)
  const base = key.split("/").pop() || key;
  const title = base.replace(/\.[a-z0-9]+$/i, "").replace(/[_-]+/g, " ").trim();

  return { era, type, source, is_memorabilia, tags, title };
}

const enriched = keys.map((k) => {
  const key = k.key ?? "";
  const meta = classify(String(key));
  return {
    key,
    size: k.size ?? null,
    lastModified: k.lastModified ?? null,
    ...meta
  };
});

fs.writeFileSync(outJson, JSON.stringify({ generatedAt: new Date().toISOString(), items: enriched }, null, 2));

const header = ["key","size","lastModified","era","type","source","is_memorabilia","tags","title"];
const lines = [header.join(",")];
for (const it of enriched) {
  const row = [
    it.key,
    it.size ?? "",
    it.lastModified ?? "",
    it.era ?? "",
    it.type ?? "",
    it.source ?? "",
    String(!!it.is_memorabilia),
    (it.tags ?? []).join("|"),
    it.title ?? ""
  ].map(v => `"${String(v).replaceAll('"','""')}"`);
  lines.push(row.join(","));
}
fs.writeFileSync(outCsv, lines.join("\n"));
NODE

echo "✓ Wrote:"
echo "  - $out_json"
echo "  - $out_csv"
