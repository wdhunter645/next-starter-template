#!/usr/bin/env bash
set -euo pipefail

# B2 S3 Smoke Test (no secrets printed)
# Requires:
#   B2_KEY_ID, B2_APP_KEY, B2_ENDPOINT, B2_BUCKET
#
# Optional:
#   B2_PREFIX (defaults to empty)

echo "============================================"
echo "B2 S3 Smoke Test"
echo "============================================"

required=(B2_KEY_ID B2_APP_KEY B2_ENDPOINT B2_BUCKET)
missing=()
for v in "${required[@]}"; do
  if [[ -z "${!v:-}" ]]; then
    missing+=("$v")
  fi
done

if (( ${#missing[@]} > 0 )); then
  echo "ERROR: Missing required env var(s): ${missing[*]}"
  exit 2
fi

# Minimal validation without printing secrets
key_id="${B2_KEY_ID}"
app_key="${B2_APP_KEY}"
endpoint="${B2_ENDPOINT}"
bucket="${B2_BUCKET}"
prefix="${B2_PREFIX:-}"

# Key format checks (informational only)
# Backblaze applicationKeyId is commonly 25 hex chars (example: 005cfd8748d7b780000000001)
if [[ "$key_id" =~ [[:space:]] ]]; then
  echo "ERROR: B2_KEY_ID contains whitespace"
  exit 2
fi
if [[ "$app_key" =~ [[:space:]] ]]; then
  echo "ERROR: B2_APP_KEY contains whitespace"
  exit 2
fi

if [[ "$key_id" =~ ^[0-9a-f]{25}$ ]]; then
  echo "✓ B2_KEY_ID looks like a 25-char hex Backblaze applicationKeyId"
else
  echo "⚠︎ B2_KEY_ID does not match the common Backblaze 25-hex format (continuing anyway)"
  echo "  - length: ${#key_id}"
fi

if [[ "$endpoint" != https://s3.*.backblazeb2.com* ]]; then
  echo "⚠︎ B2_ENDPOINT does not look like https://s3.<region>.backblazeb2.com (continuing anyway)"
fi

if ! command -v aws >/dev/null 2>&1; then
  echo "ERROR: aws CLI not found on PATH"
  exit 2
fi

echo "✓ Environment variables validated"
echo "✓ Testing connectivity to B2 bucket via S3 endpoint..."
echo "  - endpoint: ${endpoint}"
echo "  - bucket: ${bucket}"
echo "  - prefix: ${prefix}"

set +e
out="$(AWS_ACCESS_KEY_ID="$key_id" AWS_SECRET_ACCESS_KEY="$app_key" aws s3api list-objects-v2   --bucket "$bucket"   --max-keys 1   ${prefix:+--prefix "$prefix"}   --endpoint-url "$endpoint" 2>&1)"
rc=$?
set -e

if [[ $rc -ne 0 ]]; then
  echo ""
  echo "ERROR: Failed to connect to B2 bucket"
  echo ""
  echo "AWS CLI output:"
  echo ""
  echo "$out"
  echo ""
  echo "Most common causes:"
  echo "  - B2_ENDPOINT region mismatch for this bucket"
  echo "  - Key is an *account* key, not an *application key* (needs S3-compatible access)"
  echo "  - Key permissions do not include list/read for the bucket"
  echo "  - Bucket name typo"
  exit 1
fi

echo "✓ B2 bucket connectivity OK"
