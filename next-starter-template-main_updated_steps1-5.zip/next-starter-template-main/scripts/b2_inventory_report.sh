#!/usr/bin/env bash
set -euo pipefail

# Generates an inventory snapshot (JSON + CSV) from B2 via S3 API.
# Requires:
#   B2_ENDPOINT, B2_BUCKET, B2_KEY_ID, B2_APP_KEY
# Optional:
#   B2_PREFIX
#
# Output:
#   data/b2/inventory_<timestamp>.json
#   data/b2/inventory_<timestamp>.csv
#   data/b2/inventory_latest.json
#   data/b2/inventory_latest.csv

ts="$(date -u +%Y%m%dT%H%M%SZ)"
out_dir="data/b2"
mkdir -p "$out_dir"

echo "============================================"
echo "B2 Inventory Report"
echo "============================================"
echo "Timestamp: $ts"

# Fast fail if connectivity is broken
bash scripts/b2_s3_smoketest.sh

json_path="$out_dir/inventory_${ts}.json"
csv_path="$out_dir/inventory_${ts}.csv"
json_latest="$out_dir/inventory_latest.json"
csv_latest="$out_dir/inventory_latest.csv"

echo "Listing objects..."
node scripts/b2_list_objects.mjs > "$json_path"

echo "Converting to CSV..."
node - <<'NODE' "$json_path" "$csv_path"
import fs from "node:fs";

const [,, jsonPath, csvPath] = process.argv;
const raw = JSON.parse(fs.readFileSync(jsonPath, "utf8"));
const keys = raw?.keys ?? [];

const header = ["key","size","lastModified"];
const lines = [header.join(",")];

for (const k of keys) {
  const row = [
    String(k.key ?? "").replaceAll('"','""'),
    String(k.size ?? ""),
    String(k.lastModified ?? "")
  ].map(v => `"${v}"`);
  lines.push(row.join(","));
}

fs.writeFileSync(csvPath, lines.join("\n"));
NODE

cp "$json_path" "$json_latest"
cp "$csv_path" "$csv_latest"

echo "✓ Wrote:"
echo "  - $json_path"
echo "  - $csv_path"
echo "  - $json_latest"
echo "  - $csv_latest"
