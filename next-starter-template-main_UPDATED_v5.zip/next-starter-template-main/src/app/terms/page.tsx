import React from "react";
import { getSectionContent } from "@/lib/pageContent";

export const dynamic = "force-dynamic";

export default async function Page() {
  const sections = await getSectionContent("/terms", {
    "title": { content: "Terms" },
    "body_html": { content: "<p>By using this site you agree to behave respectfully and avoid abusive or unlawful activity.</p><p>User-submitted content grants the site the right to display it. Copyright or trademark concerns will be addressed promptly; infringing content will be removed.</p><p>The club operates with a zero-profit mission; any proceeds are directed to ALS-related charitable giving.</p>" },
  });

  return (
    <main style={...styles.main}>
      <h1 style={...styles.h1}>{sections.title.content}</h1>
      
      <div style={{...styles.p}} dangerouslySetInnerHTML={{ __html: sections.body_html.content }} />
    </main>
  );
}

const styles: Record<string, React.CSSProperties> = {
  main: { padding: "40px 16px", maxWidth: 900, margin: "0 auto" },
  h1: { fontSize: 34, lineHeight: 1.15, margin: "0 0 12px 0" },
  lead: { fontSize: 18, lineHeight: 1.6, margin: "0 0 18px 0" },
  p: { fontSize: 16, lineHeight: 1.7, margin: "0 0 14px 0" },
};
