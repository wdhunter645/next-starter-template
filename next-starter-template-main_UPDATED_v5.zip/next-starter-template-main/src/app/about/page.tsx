import React from "react";
import { getSectionContent } from "@/lib/pageContent";

export const dynamic = "force-dynamic";

export default async function Page() {
  const sections = await getSectionContent("/about", {
    "title": { content: "About the Lou Gehrig Fan Club" },
    "lead_html": { content: "<p>Lou Gehrig wasn\u2019t just an all\u2011time great ballplayer. He stood for resilience, humility, and character \u2014 and his story still matters.</p>" },
    "body_html": { content: "<p>This site is the club\u2019s public home: explore photos and memorabilia, learn about ALS causes we support, and follow updates as the archive grows.</p><p>We\u2019re building this as a legacy project \u2014 meant to last for decades, not weeks.</p>" },
  });

  return (
    <main style={...styles.main}>
      <h1 style={...styles.h1}>{sections.title.content}</h1>
      <div style={{...styles.lead}} dangerouslySetInnerHTML={{ __html: sections.lead_html.content }} />
      <div style={{...styles.p}} dangerouslySetInnerHTML={{ __html: sections.body_html.content }} />
    </main>
  );
}

const styles: Record<string, React.CSSProperties> = {
  main: { padding: "40px 16px", maxWidth: 900, margin: "0 auto" },
  h1: { fontSize: 34, lineHeight: 1.15, margin: "0 0 12px 0" },
  lead: { fontSize: 18, lineHeight: 1.6, margin: "0 0 18px 0" },
  p: { fontSize: 16, lineHeight: 1.7, margin: "0 0 14px 0" },
};
