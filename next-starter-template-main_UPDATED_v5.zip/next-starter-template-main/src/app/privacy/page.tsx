import React from "react";
import { getSectionContent } from "@/lib/pageContent";

export const dynamic = "force-dynamic";

export default async function Page() {
  const sections = await getSectionContent("/privacy", {
    "title": { content: "Privacy" },
    "body_html": { content: "<p>We collect the minimum information needed to run the site. Join requests store name and email so we can send a welcome message and updates.</p><p>We do not sell personal information. If you want your data removed, contact us.</p>" },
  });

  return (
    <main style={...styles.main}>
      <h1 style={...styles.h1}>{sections.title.content}</h1>
      
      <div style={{...styles.p}} dangerouslySetInnerHTML={{ __html: sections.body_html.content }} />
    </main>
  );
}

const styles: Record<string, React.CSSProperties> = {
  main: { padding: "40px 16px", maxWidth: 900, margin: "0 auto" },
  h1: { fontSize: 34, lineHeight: 1.15, margin: "0 0 12px 0" },
  lead: { fontSize: 18, lineHeight: 1.6, margin: "0 0 18px 0" },
  p: { fontSize: 16, lineHeight: 1.7, margin: "0 0 14px 0" },
};
