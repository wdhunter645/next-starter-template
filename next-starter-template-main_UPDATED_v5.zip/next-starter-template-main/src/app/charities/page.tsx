import React from "react";
import { getSectionContent } from "@/lib/pageContent";

export const dynamic = "force-dynamic";

export default async function Page() {
  const sections = await getSectionContent("/charities", {
    "title": { content: "Charities" },
    "lead_html": { content: "<p>ALS changed history when Lou Gehrig brought national attention to the disease. It remains a cause that demands research, support, and compassion.</p>" },
    "body_html": { content: "<p>The Lou Gehrig Fan Club highlights ALS-related charitable giving \u2014 not private profit.</p><ul><li>A short list of ALS organizations to start with</li><li>Occasional featured fundraisers and events</li><li>Simple guidance on donating and verifying charities</li></ul>" },
  });

  return (
    <main style={...styles.main}>
      <h1 style={...styles.h1}>{sections.title.content}</h1>
      <div style={{...styles.lead}} dangerouslySetInnerHTML={{ __html: sections.lead_html.content }} />
      <div style={{...styles.p}} dangerouslySetInnerHTML={{ __html: sections.body_html.content }} />
    </main>
  );
}

const styles: Record<string, React.CSSProperties> = {
  main: { padding: "40px 16px", maxWidth: 900, margin: "0 auto" },
  h1: { fontSize: 34, lineHeight: 1.15, margin: "0 0 12px 0" },
  lead: { fontSize: 18, lineHeight: 1.6, margin: "0 0 18px 0" },
  p: { fontSize: 16, lineHeight: 1.7, margin: "0 0 14px 0" },
};
