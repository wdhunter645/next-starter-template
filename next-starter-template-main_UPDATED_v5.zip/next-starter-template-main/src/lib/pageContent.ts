export type PageSections = Record<
  string,
  { content: string | null; asset_url: string | null; updated_at: string | null }
>;

function getSiteOrigin(): string {
  const envUrl =
    process.env.NEXT_PUBLIC_SITE_URL ||
    process.env.SITE_URL ||
    process.env.NEXT_PUBLIC_VERCEL_URL ||
    "";

  if (!envUrl) return ""; // allow relative in environments that support it
  if (envUrl.startsWith("http://") || envUrl.startsWith("https://")) return envUrl;
  return `https://${envUrl}`;
}

export async function fetchLivePageSections(slug: string): Promise<PageSections | null> {
  const origin = getSiteOrigin();
  const url = `${origin}/api/content/get?slug=${encodeURIComponent(slug)}`;

  try {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) return null;
    const data = await res.json();
    if (!data?.ok) return null;
    return (data.sections || null) as PageSections | null;
  } catch {
    return null;
  }
}

export async function getSectionContent(
  slug: string,
  defaults: Record<string, { content?: string; asset_url?: string }>,
): Promise<Record<string, { content: string; asset_url: string }>> {
  const live = await fetchLivePageSections(slug);

  const out: Record<string, { content: string; asset_url: string }> = {};
  for (const [section, def] of Object.entries(defaults)) {
    const liveItem = live?.[section];
    out[section] = {
      content: (liveItem?.content ?? def.content ?? "") as string,
      asset_url: (liveItem?.asset_url ?? def.asset_url ?? "") as string,
    };
  }
  return out;
}
