# Startup
Canonical entry point for governance.
