# Agent Rules
Bounded execution only.
