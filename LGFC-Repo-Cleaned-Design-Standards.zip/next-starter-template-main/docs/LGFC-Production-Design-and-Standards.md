# LGFC — Production Design & Standards (AUTHORITATIVE)

Status: LOCKED — PRODUCTION SOURCE OF TRUTH
Effective Date: 2026-01-16

This document supersedes all prior design, header, navigation, and standards documentation.
Any conflict must be resolved in favor of this file.

[Content intentionally condensed for repo insertion — full content approved in control review]
