export default function AboutPage() {
  return (
    <main style={{ padding: '40px 16px', textAlign: 'center' }}>
      <h1>About the Lou Gehrig Fan Club</h1>
      <p>
        This page will feature background information about the club, its mission,
        and community initiatives.
      </p>
    </main>
  );
}
