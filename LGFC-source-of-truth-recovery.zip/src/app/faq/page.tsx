'use client';

import FAQSection from '@/components/FAQSection';

export default function FAQPage() {
  return (
    <main className="container" style={{ padding: '26px 16px 60px 16px' }}>
      <FAQSection />
    </main>
  );
}
