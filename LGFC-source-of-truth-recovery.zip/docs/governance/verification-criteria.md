# Verification Criteria
Pass/fail only.
